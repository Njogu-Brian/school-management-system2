

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Create SMS Template</h4>
    <form action="<?php echo e(route('sms-templates.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Template Code *</label>
            <input type="text" name="code" class="form-control" placeholder="e.g. absent_notice" required>
            <small class="text-muted">Used to fetch template programmatically (e.g. welcome_staff)</small>
        </div>

        <div class="mb-3">
            <label class="form-label">Message Content *</label>
            <textarea name="content" class="form-control" rows="6" maxlength="300" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\communication\sms_templates\create.blade.php ENDPATH**/ ?>