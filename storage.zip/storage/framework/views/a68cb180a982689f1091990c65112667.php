

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-4">⚙️ System Settings</h4>

    <ul class="nav nav-tabs" id="settingsTab" role="tablist">
        <li class="nav-item" role="presentation">
            <a class="nav-link active" id="general-tab" data-bs-toggle="tab" href="#general" role="tab">General Info</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="branding-tab" data-bs-toggle="tab" href="#branding" role="tab">Branding</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="regional-tab" data-bs-toggle="tab" href="#regional" role="tab">Regional Settings</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="system-tab" data-bs-toggle="tab" href="#system" role="tab">System Options</a>
        </li>
        <li class="nav-item" role="presentation">
            <a class="nav-link" id="modules-tab" data-bs-toggle="tab" href="#modules" role="tab">Modules & Permissions</a>
        </li>
    </ul>

    <div class="tab-content p-4 border border-top-0 rounded-bottom" id="settingsTabContent">
        <?php echo $__env->make('settings.partials.general', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('settings.partials.branding', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('settings.partials.regional', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('settings.partials.system', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        <?php echo $__env->make('settings.partials.modules', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\settings\index.blade.php ENDPATH**/ ?>