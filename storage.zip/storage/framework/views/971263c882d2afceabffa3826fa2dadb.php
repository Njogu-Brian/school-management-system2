<div>
    <!-- Live as if you were to die tomorrow. Learn as if you were to live forever. - Mahatma Gandhi -->
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\student_assignments\show.blade.php ENDPATH**/ ?>