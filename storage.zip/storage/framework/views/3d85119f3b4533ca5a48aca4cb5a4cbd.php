<p>Hello,</p>
<p>Your account has been created.</p>
<p><strong>Email:</strong> <?php echo e($email); ?></p>
<p><strong>Password:</strong> <?php echo e($password); ?></p>
<p>Please log in and change your password immediately.</p>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\emails\credentials.blade.php ENDPATH**/ ?>