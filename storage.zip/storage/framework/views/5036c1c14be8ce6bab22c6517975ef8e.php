

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Student Details</h1>
    
    
    <div class="card mb-4">
        <div class="card-header">Student Information</div>
        <div class="card-body">
            <div class="row">
                <div class="col-md-6"><strong>Admission Number:</strong> <?php echo e($student->admission_number); ?></div>
                <div class="col-md-6"><strong>Name:</strong> <?php echo e($student->first_name); ?> <?php echo e($student->middle_name ?? ''); ?> <?php echo e($student->last_name); ?></div>
                <div class="col-md-6"><strong>Gender:</strong> <?php echo e($student->gender); ?></div>
                <div class="col-md-6"><strong>Date of Birth:</strong> <?php echo e($student->dob); ?></div>
                <div class="col-md-6"><strong>Class:</strong> <?php echo e($student->classroom->name ?? 'N/A'); ?></div>
                <div class="col-md-6"><strong>Stream:</strong> <?php echo e($student->stream->name ?? 'N/A'); ?></div>
                <div class="col-md-6"><strong>Category:</strong> <?php echo e($student->category->name ?? 'N/A'); ?></div>
                <div class="col-md-6"><strong>NEMIS Number:</strong> <?php echo e($student->nemis_number ?? 'N/A'); ?></div>
                <div class="col-md-6"><strong>KNEC Assessment Number:</strong> <?php echo e($student->knec_assessment_number ?? 'N/A'); ?></div>
            </div>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">Parent/Guardian Details</div>
        <div class="card-body">
            <?php if($student->parent): ?>
                <div class="row">
                    <div class="col-md-6"><strong>Father's Name:</strong> <?php echo e($student->parent->father_name ?? 'N/A'); ?></div>
                    <div class="col-md-6"><strong>Mother's Name:</strong> <?php echo e($student->parent->mother_name ?? 'N/A'); ?></div>
                    <div class="col-md-6"><strong>Guardian's Name:</strong> <?php echo e($student->parent->guardian_name ?? 'N/A'); ?></div>
                </div>
            <?php else: ?>
                <p>No parent/guardian information available.</p>
            <?php endif; ?>
        </div>
    </div>

    
    <div class="card mb-4">
        <div class="card-header">Uploaded Documents</div>
        <div class="card-body">
            <?php if($student->passport_photo): ?>
                <p><strong>Passport Photo:</strong> <a href="<?php echo e(asset('storage/' . $student->passport_photo)); ?>" target="_blank">View Photo</a></p>
            <?php endif; ?>
            <?php if($student->birth_certificate): ?>
                <p><strong>Birth Certificate:</strong> <a href="<?php echo e(asset('storage/' . $student->birth_certificate)); ?>" target="_blank">View Certificate</a></p>
            <?php endif; ?>
            <?php if($student->parent_id_card): ?>
                <p><strong>Parent's ID:</strong> <a href="<?php echo e(asset('storage/' . $student->parent_id_card)); ?>" target="_blank">View Parent's ID</a></p>
            <?php endif; ?>
        </div>
    </div>

    
    <a href="<?php echo e(route('students.index')); ?>" class="btn btn-primary">Back to Students</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\students\show.blade.php ENDPATH**/ ?>