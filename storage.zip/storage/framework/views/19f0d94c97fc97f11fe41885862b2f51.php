

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Online Admissions</h1>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Reference No</th>
                <th>Student Name</th>
                <th>Date of Birth</th>
                <th>Gender</th>
                <th>Form Status</th>
                <th>Payment Status</th>
                <th>Enrolled</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $admissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($admission->id); ?></td>
                    <td><?php echo e($admission->first_name); ?> <?php echo e($admission->last_name); ?></td>
                    <td><?php echo e($admission->dob); ?></td>
                    <td><?php echo e($admission->gender); ?></td>
                    <td>
                        <span class="badge <?php echo e($admission->form_status === 'Submitted' ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($admission->form_status); ?>

                        </span>
                    </td>
                    <td>
                        <span class="badge <?php echo e($admission->payment_status === 'Paid' ? 'bg-success' : 'bg-danger'); ?>">
                            <?php echo e($admission->payment_status); ?>

                        </span>
                    </td>
                    <td><?php echo e($admission->enrolled ? 'Yes' : 'No'); ?></td>
                    <td>
                        <?php if(!$admission->enrolled): ?>
                            <form action="<?php echo e(route('online-admissions.approve', $admission->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-success btn-sm">Approve</button>
                            </form>
                            <form action="<?php echo e(route('online-admissions.reject', $admission->id)); ?>" method="POST" style="display:inline;">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-danger btn-sm">Reject</button>
                            </form>
                        <?php else: ?>
                            <span class="text-success">Enrolled</span>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\online_admissions\index.blade.php ENDPATH**/ ?>