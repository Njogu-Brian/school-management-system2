

<?php $__env->startSection('content'); ?>
<h1>Edit Staff</h1>

<form action="<?php echo e(route('staff.update', $staff->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label>First Name</label>
        <input type="text" name="first_name" value="<?php echo e(old('first_name', $staff->first_name)); ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Middle Name</label>
        <input type="text" name="middle_name" value="<?php echo e(old('middle_name', $staff->middle_name)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Last Name</label>
        <input type="text" name="last_name" value="<?php echo e(old('last_name', $staff->last_name)); ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Email</label>
        <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Phone Number</label>
        <input type="text" name="phone_number" value="<?php echo e(old('phone_number', $staff->phone_number)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>ID Number</label>
        <input type="text" name="id_number" value="<?php echo e(old('id_number', $staff->id_number)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Date of Birth</label>
        <input type="date" name="date_of_birth" value="<?php echo e(old('date_of_birth', $staff->date_of_birth)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Gender</label>
        <select name="gender" class="form-control">
            <option value="">Select Gender</option>
            <option value="male" <?php echo e($staff->gender == 'male' ? 'selected' : ''); ?>>Male</option>
            <option value="female" <?php echo e($staff->gender == 'female' ? 'selected' : ''); ?>>Female</option>
        </select>
    </div>

    <div class="mb-3">
        <label>Marital Status</label>
        <select name="marital_status" class="form-control">
            <option value="">Select Status</option>
            <option value="single" <?php echo e($staff->marital_status == 'single' ? 'selected' : ''); ?>>Single</option>
            <option value="married" <?php echo e($staff->marital_status == 'married' ? 'selected' : ''); ?>>Married</option>
        </select>
    </div>

    <div class="mb-3">
        <label>Address</label>
        <input type="text" name="address" value="<?php echo e(old('address', $staff->address)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Emergency Contact Name</label>
        <input type="text" name="emergency_contact_name" value="<?php echo e(old('emergency_contact_name', $staff->emergency_contact_name)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Emergency Contact Phone</label>
        <input type="text" name="emergency_contact_phone" value="<?php echo e(old('emergency_contact_phone', $staff->emergency_contact_phone)); ?>" class="form-control">
    </div>

    <div class="mb-3">
        <label>Roles</label>
        <select name="roles[]" multiple class="form-control" required>
            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($role->id); ?>" <?php echo e($user->roles->contains('id', $role->id) ? 'selected' : ''); ?>>
                    <?php echo e(ucfirst($role->name)); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <small>Hold Ctrl (Cmd on Mac) to select multiple roles</small>
    </div>

    <button type="submit" class="btn btn-primary">Update Staff</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\staff\edit.blade.php ENDPATH**/ ?>