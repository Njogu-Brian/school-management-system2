<form action="<?php echo e(route('communication.send')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <input type="hidden" name="type" value="sms">

    <div class="mb-3">
        <label for="template_id" class="form-label">SMS Template</label>
        <select name="template_id" class="form-control" required>
            <?php $__currentLoopData = $templates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $template): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($template->id); ?>"><?php echo e($template->subject); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="target" class="form-label">Message To</label>
        <select name="target" class="form-control" required>
            <option value="students">Students</option>
            <option value="parents">Parents</option>
            <option value="teachers">Teachers</option>
            <option value="staff">Staff</option>
        </select>
    </div>

    <button type="submit" class="btn btn-success">Send SMS</button>
</form>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\partials\sms-form.blade.php ENDPATH**/ ?>