

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Edit SMS Template</h4>
    <form action="<?php echo e(route('sms-templates.update', $smsTemplate->id)); ?>" method="POST">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" value="<?php echo e($smsTemplate->title); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Template Code *</label>
            <input type="text" name="code" class="form-control" value="<?php echo e($smsTemplate->code); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Message Content *</label>
            <textarea name="message" class="form-control" rows="6" maxlength="300" required><?php echo e($smsTemplate->content); ?></textarea>
        </div>

        <button type="submit" class="btn btn-success">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\communication\sms_templates\edit.blade.php ENDPATH**/ ?>