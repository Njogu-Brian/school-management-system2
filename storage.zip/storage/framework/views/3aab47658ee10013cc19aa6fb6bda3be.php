<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Teacher Dashboard</h1>

    <div class="row">
        <div class="col-md-12">
            <h3>My Students' Attendance</h3>
            <?php echo $__env->make('dashboard.partials.summary', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\dashboard\teacher.blade.php ENDPATH**/ ?>