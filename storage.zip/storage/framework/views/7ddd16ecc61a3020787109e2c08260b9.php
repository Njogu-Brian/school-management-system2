

<?php $__env->startSection('content'); ?>
<h1>Drop-Off Points Management</h1>

<a href="<?php echo e(route('dropoffpoints.create')); ?>" class="btn btn-success mb-3">Add New Drop-Off Point</a>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Drop-Off Point Name</th>
            <th>Route</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $dropOffPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($point->name); ?></td>
                <td><?php echo e($point->route->name ?? 'No Route'); ?></td>
                <td>
                    <a href="<?php echo e(route('dropoffpoints.edit', $point->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                    <form action="<?php echo e(route('dropoffpoints.destroy', $point->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Delete this drop-off point?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="3" class="text-center">No Drop-Off Points Found</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\dropoffpoints\index.blade.php ENDPATH**/ ?>