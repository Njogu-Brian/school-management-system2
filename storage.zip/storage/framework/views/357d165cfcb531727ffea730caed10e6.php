<?php $__env->startSection('content'); ?>
<h1>Edit Vehicle</h1>

<form action="<?php echo e(route('vehicles.update', $vehicle)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>

    <div class="mb-3">
        <label for="vehicle_number">Vehicle Number</label>
        <input type="text" name="vehicle_number" class="form-control" value="<?php echo e($vehicle->vehicle_number); ?>" required>
    </div>

    <div class="mb-3">
        <label for="make">Make</label>
        <input type="text" name="make" class="form-control" value="<?php echo e($vehicle->make); ?>">
    </div>

    <div class="mb-3">
        <label for="model">Model</label>
        <input type="text" name="model" class="form-control" value="<?php echo e($vehicle->model); ?>">
    </div>

    <div class="mb-3">
        <label for="type">Vehicle Type</label>
        <input type="text" name="type" class="form-control" value="<?php echo e($vehicle->type); ?>">
    </div>

    <div class="mb-3">
        <label for="capacity">Capacity</label>
        <input type="number" name="capacity" class="form-control" value="<?php echo e($vehicle->capacity); ?>">
    </div>

    <div class="mb-3">
        <label for="chassis_number">Chassis Number</label>
        <input type="text" name="chassis_number" class="form-control" value="<?php echo e($vehicle->chassis_number); ?>">
    </div>

    <div class="mb-3">
        <label for="insurance_document">Insurance Document</label>
        <input type="file" name="insurance_document" class="form-control">
        <?php if($vehicle->insurance_document): ?>
            <small>Current File: <a href="<?php echo e(asset('storage/' . $vehicle->insurance_document)); ?>" target="_blank">View</a></small>
        <?php endif; ?>
    </div>

    <div class="mb-3">
        <label for="logbook_document">Logbook Document</label>
        <input type="file" name="logbook_document" class="form-control">
        <?php if($vehicle->logbook_document): ?>
            <small>Current File: <a href="<?php echo e(asset('storage/' . $vehicle->logbook_document)); ?>" target="_blank">View</a></small>
        <?php endif; ?>
    </div>

    <button type="submit" class="btn btn-primary">Update Vehicle</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\vehicles\edit.blade.php ENDPATH**/ ?>