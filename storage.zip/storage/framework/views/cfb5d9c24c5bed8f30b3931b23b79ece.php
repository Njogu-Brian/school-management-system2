<?php $__env->startSection('content'); ?>
<h1>Vehicles</h1>

<a href="<?php echo e(route('vehicles.create')); ?>" class="btn btn-success mb-3">Add New Vehicle</a>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Vehicle Number</th>
            <th>Driver Name</th>
            <th>Assigned Students</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($vehicle->vehicle_number); ?></td>
                <td><?php echo e($vehicle->driver_name); ?></td>
                <td>
                    <?php $__currentLoopData = $vehicle->trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div><?php echo e($trip->student->name); ?> (Class: <?php echo e($trip->student->class); ?>)</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </td>
                <td>
                    <a href="<?php echo e(route('vehicles.edit', $vehicle)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('vehicles.destroy', $vehicle)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger"
                                onclick="return confirm('Delete this vehicle?')">Delete</button>
                    </form>
                </td>
                <td>
                    <?php if($vehicle->insurance_document): ?>
                        <a href="<?php echo e(asset('storage/' . $vehicle->insurance_document)); ?>" target="_blank">Insurance Document</a><br>
                    <?php endif; ?>
                    <?php if($vehicle->logbook_document): ?>
                        <a href="<?php echo e(asset('storage/' . $vehicle->logbook_document)); ?>" target="_blank">Logbook Document</a>
                    <?php endif; ?>
                </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<hr>
<h3>Assign Driver to Existing Vehicle</h3>
<form action="<?php echo e(route('transport.assign.driver')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="vehicle_id">Select Vehicle</label>
        <select name="vehicle_id" class="form-control" required>
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vehicle->id); ?>">
                    <?php echo e($vehicle->vehicle_number); ?> <?php echo e($vehicle->driver_name ? "- Current Driver: $vehicle->driver_name" : ''); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <div class="mb-3">
        <label for="driver_name">Select Driver</label>
        <select name="driver_name" class="form-control" required>
            <option value="">-- Select Driver --</option>
            <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($driver->name); ?>"><?php echo e($driver->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Assign Driver</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\vehicles\index.blade.php ENDPATH**/ ?>