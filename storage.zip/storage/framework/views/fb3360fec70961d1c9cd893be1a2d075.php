

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Add New Stream</h1>
    <form action="<?php echo e(route('streams.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>Stream Name</label>
            <input type="text" name="name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Select Classrooms</label>
            <div>
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="classroom_ids[]" value="<?php echo e($classroom->id); ?>" id="classroom_<?php echo e($classroom->id); ?>">
                        <label class="form-check-label" for="classroom_<?php echo e($classroom->id); ?>">
                            <?php echo e($classroom->name); ?>

                        </label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <button type="submit" class="btn btn-success">Add Stream</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\streams\create.blade.php ENDPATH**/ ?>