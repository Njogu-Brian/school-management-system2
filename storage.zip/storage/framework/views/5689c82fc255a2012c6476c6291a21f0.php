

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Class Management</h1>
    <p>Create and manage classes for the school.</p>
    <a href="#" class="btn btn-primary">Create New Class</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\academics\class.blade.php ENDPATH**/ ?>