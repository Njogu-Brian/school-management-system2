<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Attendance for <?php echo e($attendance->student->name); ?></h1>

    <form method="POST" action="<?php echo e(route('attendance.update', $attendance->id)); ?>">
        <?php echo csrf_field(); ?>

        <label for="is_present">Attendance Status:</label>
        <select name="is_present" id="is_present" class="form-control">
            <option value="1" <?php echo e($attendance->is_present ? 'selected' : ''); ?>>Present</option>
            <option value="0" <?php echo e(!$attendance->is_present ? 'selected' : ''); ?>>Absent</option>
        </select>

        <label for="reason">Reason (if absent):</label>
        <input type="text" name="reason" id="reason" class="form-control" value="<?php echo e(old('reason', $attendance->reason)); ?>" <?php echo e($attendance->is_present ? 'disabled' : ''); ?>>

        <button type="submit" class="btn btn-primary mt-3">Update Attendance</button>
    </form>
</div>

<script>
    document.getElementById('is_present').addEventListener('change', function() {
        let reasonField = document.getElementById('reason');
        if (this.value == "1") {
            reasonField.value = ""; // Clear reason when marking present
            reasonField.disabled = true;
        } else {
            reasonField.disabled = false;
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\attendance\edit.blade.php ENDPATH**/ ?>