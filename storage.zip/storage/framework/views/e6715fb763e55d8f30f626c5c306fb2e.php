

<?php $__env->startSection('content'); ?>
<h1>Manage Staff</h1>

<a href="<?php echo e(route('staff.create')); ?>" class="btn btn-success mb-3">Add New Staff</a>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<table class="table table-bordered">
    <thead>
        <tr>
            <th>Name</th>
            <th>Email</th>
            <th>Role(s)</th>
            <th>Status</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $staff; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($member->first_name); ?> <?php echo e($member->last_name); ?></td>
            <td><?php echo e($member->email); ?></td>
            <td>
                <?php if($member->user && $member->user->roles): ?>
                    <?php $__currentLoopData = $member->user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php echo e(ucfirst($role->name)); ?><?php if(!$loop->last): ?>, <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <span class="text-muted">No roles</span>
                <?php endif; ?>
            </td>
            <td><?php echo e(ucfirst($member->status ?? 'active')); ?></td>
            <td>
                <a href="<?php echo e(route('staff.edit', $member)); ?>" class="btn btn-sm btn-primary">Edit</a>

                <?php if($member->status === 'archived'): ?>
                    <form action="<?php echo e(route('staff.restore', $member->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-success">Restore</button>
                    </form>
                <?php else: ?>
                    <form action="<?php echo e(route('staff.archive', $member->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <button class="btn btn-sm btn-warning">Archive</button>
                    </form>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/staff/index.blade.php ENDPATH**/ ?>