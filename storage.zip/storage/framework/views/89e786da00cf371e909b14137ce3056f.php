

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Subjects Management</h1>
    <p>Add, edit, or remove subjects for different classes.</p>
    <a href="#" class="btn btn-primary">Add New Subject</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\academics\subjects.blade.php ENDPATH**/ ?>