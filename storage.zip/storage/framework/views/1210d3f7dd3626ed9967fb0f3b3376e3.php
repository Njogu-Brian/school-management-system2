<?php if($filtersApplied && $students->isNotEmpty()): ?>
    <div class="card mt-3">
        <div class="card-header">Filtered Students</div>
        <div class="card-body">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Name</th>
                        <th>Class</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <!-- Display Full Name -->
                            <td><?php echo e($student->full_name ?? "{$student->first_name} {$student->middle_name} {$student->last_name}"); ?></td>
                            
                            <!-- Display Class Name -->
                            <td><?php echo e($student->classroom->name ?? 'N/A'); ?></td>
                            
                            <!-- Display Attendance Status -->
                            <td>
                                <?php if($student->attendances->where('date', $selectedDate)->where('is_present', 1)->count()): ?>
                                    <span class="badge bg-success">Present</span>
                                <?php elseif($student->attendances->where('date', $selectedDate)->where('is_present', 0)->count()): ?>
                                    <span class="badge bg-danger">Absent</span>
                                <?php else: ?>
                                    <span class="badge bg-warning">Not Marked</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php elseif($filtersApplied): ?>
    <p>No students found for the selected filters.</p>
<?php endif; ?>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/dashboard/partials/students.blade.php ENDPATH**/ ?>