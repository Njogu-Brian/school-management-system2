

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Promote Students</h1>
    
    <form action="#" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Select Class to Promote From</label>
            <select class="form-control" name="current_class_id">
                <option value="1">Class A</option>
                <option value="2">Class B</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Select Class to Promote To</label>
            <select class="form-control" name="new_class_id">
                <option value="3">Class C</option>
                <option value="4">Class D</option>
            </select>
        </div>

        <button type="submit" class="btn btn-success">Promote Students</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\academics\promote_students.blade.php ENDPATH**/ ?>