

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Edit Email Template</h4>
    <form action="<?php echo e(route('email-templates.update', $emailTemplate->id)); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label class="form-label">Template Code *</label>
            <input type="text" name="code" class="form-control" value="<?php echo e(old('code', $smsTemplate->code ?? $emailTemplate->code ?? '')); ?>" required>
            <small class="text-muted">Use a unique identifier like: welcome_staff, absent_notification</small>
        </div>
        <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" value="<?php echo e($emailTemplate->title); ?>" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Attachment</label>
            <input type="file" name="attachment" class="form-control">
            <?php if($emailTemplate->attachment): ?>
                <p>Current: <a href="<?php echo e(asset('storage/' . $emailTemplate->attachment)); ?>" target="_blank">View</a></p>
            <?php endif; ?>
        </div>

        <div class="mb-3">
            <label class="form-label">Message *</label>
            <textarea name="message" class="form-control rich-text" rows="10" required><?php echo e($emailTemplate->message); ?></textarea>
        </div>

        <button type="submit" class="btn btn-success">Update</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\communication\email_templates\edit.blade.php ENDPATH**/ ?>