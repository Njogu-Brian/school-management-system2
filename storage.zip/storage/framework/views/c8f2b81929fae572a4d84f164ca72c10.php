

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Classroom</h1>

    <form action="<?php echo e(route('classrooms.update', $classroom->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Class Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($classroom->name); ?>" required>
        </div>

        <div class="mb-3">
            <label>Assign Teachers</label>
            <select name="teacher_ids[]" class="form-control" multiple>
                <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($teacher->id); ?>" <?php if(in_array($teacher->id, $assignedTeachers)): ?> selected <?php endif; ?>>
                        <?php echo e($teacher->first_name); ?> <?php echo e($teacher->last_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update Classroom</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\classrooms\edit.blade.php ENDPATH**/ ?>