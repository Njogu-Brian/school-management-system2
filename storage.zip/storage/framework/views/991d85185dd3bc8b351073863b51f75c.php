<h2>Welcome to Royal Kings School</h2>
<p>Hello <?php echo e($user->name); ?>,</p>

<p>Your account has been created. Here are your login credentials:</p>

<ul>
    <li><strong>Email:</strong> <?php echo e($user->email); ?></li>
    <li><strong>Password:</strong> <?php echo e($password); ?></li>
</ul>

<p>Please log in and change your password immediately.</p>

<p>Regards,<br>School Admin</p>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\emails\staff-welcome.blade.php ENDPATH**/ ?>