<div class="card">
    <div class="card-header">Filter Students</div>
    <div class="card-body">
        <form method="GET" action="<?php echo e(route('admin.dashboard')); ?>" class="mb-3">
            <div class="row">
                <!-- Date Filter -->
                <div class="col-md-4">
                    <input type="date" name="date" class="form-control" value="<?php echo e(request('date', $selectedDate)); ?>">
                </div>

                <!-- Class Filter -->
                <div class="col-md-4">
                    <select name="class" class="form-control">
                        <option value="">All Classes</option>
                        <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($class); ?>" <?php echo e(request('class') == $class ? 'selected' : ''); ?>>
                                <?php echo e($class); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <!-- Status Filter -->
                <div class="col-md-4">
                    <select name="status" class="form-control">
                        <option value="">All Status</option>
                        <option value="present" <?php echo e(request('status') == 'present' ? 'selected' : ''); ?>>Present</option>
                        <option value="absent" <?php echo e(request('status') == 'absent' ? 'selected' : ''); ?>>Absent</option>
                    </select>
                </div>

                <!-- Search Filter -->
                <div class="col-md-4 mt-2">
                    <input type="text" name="search" class="form-control" placeholder="Search by Name" value="<?php echo e(request('search')); ?>">
                </div>
            </div>

            <button type="submit" class="btn btn-primary mt-2">Apply Filters</button>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="btn btn-secondary mt-2">Reset</a>
        </form>
    </div>
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/dashboard/partials/filters.blade.php ENDPATH**/ ?>