

<?php $__env->startSection('content'); ?>
<h1>Add Drop-Off Point</h1>

<form action="<?php echo e(route('dropoffpoints.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <div class="mb-3">
        <label for="name">Drop-Off Point Name</label>
        <input type="text" name="name" class="form-control" required>
    </div>

    <div class="mb-3">
        <label for="route_id">Assign to Route</label>
        <select name="route_id" class="form-control" required>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($route->id); ?>"><?php echo e($route->name); ?> (<?php echo e($route->area); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Add Drop-Off Point</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\dropoffpoints\create.blade.php ENDPATH**/ ?>