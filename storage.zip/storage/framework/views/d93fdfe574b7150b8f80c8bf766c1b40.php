<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Student Admission</h1>

    <form action="<?php echo e(route('students.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <h4>Student Information</h4>
        <div class="mb-3">
            <label>First Name</label>
            <input type="text" name="first_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Middle Name (Optional)</label>
            <input type="text" name="middle_name" class="form-control">
        </div>

        <div class="mb-3">
            <label>Last Name</label>
            <input type="text" name="last_name" class="form-control" required>
        </div>

        <div class="mb-3">
            <label>Gender</label>
            <select name="gender" class="form-control" required>
                <option value="Male">Male</option>
                <option value="Female">Female</option>
            </select>
        </div>
        <div class="mb-3">
            <label>Date of Birth</label>
            <input type="date" name="dob" class="form-control">
        </div>

        
        <div class="mb-3">
            <label>Class</label>
            <select id="classroom" name="classroom_id" class="form-control" required>
                <option value="">Select Class</option>
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($classroom->id); ?>"><?php echo e($classroom->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Stream</label>
            <select id="stream" name="stream_id" class="form-control">
                <option value="">Select Stream (Optional)</option>
            </select>
        </div>

        <div class="mb-3">
            <label>Student Category</label>
            <select name="category_id" class="form-control">
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        
        <div class="mb-3">
            <label>NEMIS Number</label>
            <input type="text" name="nemis_number" class="form-control">
        </div>
        <div class="mb-3">
            <label>KNEC Assessment Number</label>
            <input type="text" name="knec_assessment_number" class="form-control">
        </div>

        
        <h4>Sibling Management</h4>
        <label>Link to Sibling (Optional)</label>
        <select name="sibling_id" class="form-control" id="sibling-select">
            <option value="">Select Sibling</option>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($student->id); ?>"><?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?> (Adm: <?php echo e($student->admission_number); ?>)</option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <p id="parent-info" class="text-muted">Parent details will be populated if a sibling is selected. You can still edit the details below if necessary.</p>

        
        <h4>Parent/Guardian Information</h4>

        
        <h5>Father's Information</h5>
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="father_name" class="form-control parent-field" required>
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input type="text" name="father_phone" class="form-control parent-field" required>
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="father_email" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>ID Number</label>
            <input type="text" name="father_id_number" class="form-control parent-field">
        </div>

        
        <h5>Mother's Information</h5>
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="mother_name" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input type="text" name="mother_phone" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="mother_email" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>ID Number</label>
            <input type="text" name="mother_id_number" class="form-control parent-field">
        </div>

        
        <h5>Guardian (Optional)</h5>
        <div class="mb-3">
            <label>Name</label>
            <input type="text" name="guardian_name" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>Phone</label>
            <input type="text" name="guardian_phone" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>Email</label>
            <input type="email" name="guardian_email" class="form-control parent-field">
        </div>
        <div class="mb-3">
            <label>Relationship</label>
            <input type="text" name="guardian_relationship" class="form-control parent-field">
        </div>

        
        <h4>Document Uploads</h4>
        <div class="mb-3">
            <label>Passport Photo</label>
            <input type="file" name="passport_photo" class="form-control">
        </div>
        <div class="mb-3">
            <label>Birth Certificate</label>
            <input type="file" name="birth_certificate" class="form-control">
        </div>
        <div class="mb-3">
            <label>Parent's ID (PDF or Image)</label>
            <input type="file" name="parent_id_card" class="form-control">
        </div>

        
        <button type="submit" class="btn btn-success">Submit Admission</button>
    </form>
</div>

<script>
document.getElementById('sibling-select').addEventListener('change', function() {
    const siblingId = this.value;
    if (siblingId) {
        fetch(`/api/siblings/${siblingId}`)
            .then(response => response.json())
            .then(data => {
                document.querySelector("input[name='father_name']").value = data.father_name;
                document.querySelector("input[name='father_phone']").value = data.father_phone;
                document.querySelector("input[name='mother_name']").value = data.mother_name;
                document.querySelector("input[name='mother_phone']").value = data.mother_phone;
                document.querySelector("input[name='guardian_name']").value = data.guardian_name;
                document.querySelector("input[name='guardian_phone']").value = data.guardian_phone;
            })
            .catch(error => {
                console.error("Error fetching sibling data:", error);
            });
    }
});
document.getElementById('classroom').addEventListener('change', function() {
    const classroomId = this.value;
    const streamSelect = document.getElementById('stream');

    // Clear previous options
    streamSelect.innerHTML = '<option value="">Select Stream (Optional)</option>';

    if (classroomId) {
        fetch('/get-streams', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': document.querySelector('input[name=_token]').value
            },
            body: JSON.stringify({ classroom_id: classroomId })
        })
        .then(response => response.json())
        .then(data => {
            if (data.length > 0) {
                data.forEach(stream => {
                    const option = document.createElement('option');
                    option.value = stream.id;
                    option.textContent = stream.name;
                    streamSelect.appendChild(option);
                });
            } else {
                // Show no streams available and allow form submission without it
                const option = document.createElement('option');
                option.textContent = 'No Active Streams';
                option.disabled = true;
                streamSelect.appendChild(option);
            }
        })
        .catch(error => console.error('Error fetching streams:', error));
    }
});

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/students/create.blade.php ENDPATH**/ ?>