<?php $__env->startSection('content'); ?>
    <h1>Notify Kitchen</h1>

    <?php if(session('success')): ?>
        <div style="color: green; margin-bottom: 10px;">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('notify-kitchen.submit')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>Class</th>
                    <th>Present Students</th>
                </tr>
            </thead>
                <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $classCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classCount): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($classCount->class); ?></td>
                            <td><?php echo e($classCount->count); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="2" class="text-center">No attendance marked yet.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
        </table>
        <button type="submit" class="btn btn-primary">Notify Kitchen</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\notify-kitchen.blade.php ENDPATH**/ ?>