<div class="tab-pane fade show active" id="general" role="tabpanel">
    <form method="POST" action="<?php echo e(route('settings.update.general')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>School Name</label>
            <input type="text" class="form-control" name="school_name"
                value="<?php echo e(old('school_name', $settings['school_name']->value ?? '')); ?>">
        </div>

        <div class="mb-3">
            <label>Address</label>
            <textarea class="form-control" name="school_address"><?php echo e(old('school_address', $settings['school_address']->value ?? '')); ?></textarea>
        </div>

        <div class="mb-3">
            <label>Phone</label>
            <input type="text" class="form-control" name="school_phone"
                value="<?php echo e(old('school_phone', $settings['school_phone']->value ?? '')); ?>">
        </div>

        <div class="mb-3">
            <label>Email</label>
            <input type="email" class="form-control" name="school_email"
                value="<?php echo e(old('school_email', $settings['school_email']->value ?? '')); ?>">
        </div>

        <button class="btn btn-primary">Save General Info</button>
    </form>
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/settings/partials/general.blade.php ENDPATH**/ ?>