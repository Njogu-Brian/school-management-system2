

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Classroom Management</h1>
    <a href="<?php echo e(route('classrooms.create')); ?>" class="btn btn-primary mb-3">Add New Classroom</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Class Name</th>
                <th>Streams</th>
                <th>Teacher</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($classroom->name); ?></td>
                
                <!-- Display Streams -->
                <td>
                    <?php if($classroom->streams->count()): ?>
                        <?php $__currentLoopData = $classroom->streams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stream): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span class="badge bg-info"><?php echo e($stream->name); ?></span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <span class="text-muted">No Stream Assigned</span>
                    <?php endif; ?>
                </td>

                <!-- Display Teacher (If implemented) -->
                <td>
                    <?php if($classroom->teachers->count()): ?>
                        <?php $__currentLoopData = $classroom->teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($teacher->first_name); ?> <?php echo e($teacher->last_name); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        Not Assigned
                    <?php endif; ?>
                </td>

                <td>
                    <a href="<?php echo e(route('classrooms.edit', $classroom->id)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('classrooms.destroy', $classroom->id)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger" onclick="return confirm('Are you sure?')">Delete</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\classrooms\index.blade.php ENDPATH**/ ?>