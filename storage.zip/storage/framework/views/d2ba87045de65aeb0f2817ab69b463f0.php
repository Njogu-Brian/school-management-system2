
<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>📋 Email & SMS Log</h4>
    <table class="table table-bordered">
        <thead>
            <tr>
                <th>Title</th>
                <th>Target</th>
                <th>Type</th>
                <th>Status</th>
                <th>Sent At</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($log->template->title ?? '-'); ?></td>
                    <td><?php echo e(ucfirst($log->target_type)); ?></td>
                    <td><?php echo e(strtoupper($log->type)); ?></td>
                    <td>
                        <?php if($log->status === 'sent'): ?>
                            <span class="badge bg-success">Sent</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Pending</span>
                        <?php endif; ?>
                    </td>
                    <td><?php echo e($log->sent_at ?? '-'); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php echo e($logs->links()); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\communication\logs.blade.php ENDPATH**/ ?>