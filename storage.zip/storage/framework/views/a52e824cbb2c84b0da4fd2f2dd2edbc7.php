

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>📢 Announcements</h4>
    <a href="<?php echo e(route('announcements.create')); ?>" class="btn btn-success mb-3">+ New Announcement</a>

    <?php $__currentLoopData = $announcements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $announcement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card mb-3">
            <div class="card-body">
                <h5><?php echo e($announcement->title); ?></h5>
                <p><?php echo e($announcement->content); ?></p>
                <small>
                    <?php if($announcement->expires_at): ?>
                        Expires: <?php echo e($announcement->expires_at->format('F j, Y')); ?>

                    <?php else: ?>
                        No expiry
                    <?php endif; ?>
                    | Status: <strong><?php echo e($announcement->active ? 'Active' : 'Inactive'); ?></strong>
                </small>
                <div class="mt-2">
                    <a href="<?php echo e(route('announcements.edit', $announcement)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form method="POST" action="<?php echo e(route('announcements.destroy', $announcement)); ?>" class="d-inline">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button class="btn btn-sm btn-danger">Delete</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/communication/announcements/index.blade.php ENDPATH**/ ?>