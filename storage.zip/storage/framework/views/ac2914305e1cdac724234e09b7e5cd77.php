<div class="card mt-3">
    <div class="card-header">Attendance Summary (<?php echo e($selectedDate); ?>)</div>
    <div class="card-body">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Class</th>
                    <th>Present</th>
                    <th>Absent</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $attendanceSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class => $summary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($class); ?></td>
                        <td><?php echo e($summary['present']); ?></td>
                        <td><?php echo e($summary['absent']); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/dashboard/partials/summary.blade.php ENDPATH**/ ?>