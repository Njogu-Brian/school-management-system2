

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Stream</h1>

    <form action="<?php echo e(route('streams.update', $stream->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-3">
            <label>Stream Name</label>
            <input type="text" name="name" class="form-control" value="<?php echo e($stream->name); ?>" required>
        </div>

        <div class="mb-3">
            <label>Assign Classrooms</label>
            <div class="row">
                <?php $__currentLoopData = $classrooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $classroom): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4">
                        <input type="checkbox" name="classroom_ids[]" value="<?php echo e($classroom->id); ?>"
                        <?php echo e($stream->classrooms->contains($classroom->id) ? 'checked' : ''); ?>>
                        <label><?php echo e($classroom->name); ?></label>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Update Stream</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\streams\edit.blade.php ENDPATH**/ ?>