

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Teacher Timetable Management</h1>

    <p>Manage teacher timetables here. Assign classes and subjects to teachers.</p>

    <a href="#" class="btn btn-primary">Add Teacher Timetable</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\academics\teacher_timetable.blade.php ENDPATH**/ ?>