<div class="tab-pane fade" id="regional" role="tabpanel">
    <form method="POST" action="<?php echo e(route('settings.update.regional')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Timezone</label>
            <input type="text" class="form-control" name="timezone" 
                value="<?php echo e(old('timezone', $settings['timezone']->value ?? '')); ?>">
        </div>
        <div class="mb-3">
            <label>Currency</label>
            <input type="text" class="form-control" name="currency" 
                value="<?php echo e(old('currency', $settings['currency']->value ?? '')); ?>">
        </div>
        <button class="btn btn-primary">Save Regional Settings</button>
    </form>
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/settings/partials/regional.blade.php ENDPATH**/ ?>