

<?php $__env->startSection('content'); ?>
<h1>Routes Management</h1>

<!-- Add New Route -->
<a href="<?php echo e(route('routes.create')); ?>" class="btn btn-success mb-3">Add New Route</a>

<?php if(session('success')): ?>
    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
<?php endif; ?>

<!-- Routes List -->
<h3>All Routes</h3>
<table class="table table-bordered">
    <thead>
        <tr>
            <th>Route Name</th>
            <th>Area</th>
            <th>Assigned Vehicles</th>
            <th>Drop-Off Points</th>
            <th>Actions</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($route->name); ?></td>
                <td><?php echo e($route->area); ?></td>
                <td>
                    <?php $__empty_1 = true; $__currentLoopData = $route->vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo e($vehicle->vehicle_number); ?> (Driver: <?php echo e($vehicle->driver_name ?? 'Unassigned'); ?>)<br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-muted">No Vehicle Assigned</span>
                    <?php endif; ?>
                </td>
                <td>
                    <?php $__empty_1 = true; $__currentLoopData = $route->dropOffPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php echo e($point->name); ?> <br>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <span class="text-muted">No Drop-Off Points Assigned</span>
                    <?php endif; ?>
                </td>
                <td>
                    <a href="<?php echo e(route('routes.edit', $route)); ?>" class="btn btn-sm btn-primary">Edit</a>
                    <form action="<?php echo e(route('routes.destroy', $route)); ?>" method="POST" style="display:inline;">
                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-sm btn-danger" onclick="return confirm('Delete this route?')">Delete</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<hr>

<!-- Assign Student to Route, Trip, and Drop-Off Point -->
<h3>Assign Student to Route</h3>
<form action="<?php echo e(route('transport.assign.student')); ?>" method="POST">
    <?php echo csrf_field(); ?>

    <!-- Student Selection -->
    <div class="mb-3">
        <label for="student_id">Select Student</label>
        <select name="student_id" class="form-control" required>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($student->id); ?>">
                    <?php echo e($student->full_name); ?> (Class: <?php echo e($student->classroom->name ?? 'N/A'); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Route Selection -->
    <div class="mb-3">
        <label for="route_id">Select Route</label>
        <select name="route_id" class="form-control" id="route-select" required>
            <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($route->id); ?>">
                    <?php echo e($route->name); ?> - <?php echo e($route->area); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Vehicle Selection (Filtered by Route) -->
    <div class="mb-3">
        <label for="vehicle_id">Select Vehicle (optional)</label>
        <select name="vehicle_id" class="form-control" id="vehicle-select">
            <option value="">-- None --</option>
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vehicle->id); ?>" data-route="<?php echo e($vehicle->route_id); ?>">
                    <?php echo e($vehicle->vehicle_number); ?> - Driver: <?php echo e($vehicle->driver_name ?? 'Unassigned'); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Trip Selection -->
    <div class="mb-3">
        <label for="trip_id">Select Trip</label>
        <select name="trip_id" class="form-control">
            <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($trip->id); ?>">
                    <?php echo e($trip->name); ?> (<?php echo e($trip->type); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <!-- Drop-Off Point Selection -->
    <div class="mb-3">
        <label for="drop_off_point_id">Select Drop-Off Point</label>
        <select name="drop_off_point_id" class="form-control" id="drop-off-point-select">
            <option value="">-- Select Drop-Off Point --</option>
            <?php $__currentLoopData = $dropOffPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($point->id); ?>" data-route="<?php echo e($point->route_id); ?>">
                    <?php echo e($point->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>

    <button type="submit" class="btn btn-primary">Assign Student</button>
</form>

<?php $__env->stopSection(); ?>

<!-- Filtering Logic for Vehicles and Drop-Off Points -->
<script>
document.getElementById('route-select').addEventListener('change', function () {
    const selectedRouteId = this.value;

    // Filter Vehicles
    const vehicleSelect = document.getElementById('vehicle-select');
    Array.from(vehicleSelect.options).forEach(option => {
        option.style.display = option.getAttribute('data-route') === selectedRouteId || option.value === "" 
            ? 'block' : 'none';
    });

    // Filter Drop-Off Points
    const dropOffSelect = document.getElementById('drop-off-point-select');
    Array.from(dropOffSelect.options).forEach(option => {
        option.style.display = option.getAttribute('data-route') === selectedRouteId || option.value === ""
            ? 'block' : 'none';
    });
});
</script>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\routes\index.blade.php ENDPATH**/ ?>