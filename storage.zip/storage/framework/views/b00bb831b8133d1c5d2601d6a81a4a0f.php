

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Class Timetable Management</h1>

    <p>Here you can create, edit, and view class timetables.</p>

    <a href="#" class="btn btn-primary">Add New Timetable</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\academics\class_timetable.blade.php ENDPATH**/ ?>