
<?php $__env->startSection('content'); ?>
<div class="container">
    <h4 class="mb-3">Assign Permissions</h4>
    <form method="POST" action="<?php echo e(route('settings.update.permissions')); ?>">
        <?php echo csrf_field(); ?>
        <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module => $features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h5 class="mt-4"><?php echo e($module); ?></h5>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Feature</th>
                        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <th><?php echo e($role->name); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($permission->feature); ?></td>
                            <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php
                                    $pivot = $role->permissions->find($permission->id)?->pivot ?? null;
                                ?>
                                <td>
                                    <div class="form-check">
                                        <label>V <input type="checkbox" name="permissions[<?php echo e($role->id); ?>][<?php echo e($permission->id); ?>][view]" <?php echo e($pivot?->can_view ? 'checked' : ''); ?>></label>
                                        <label>A <input type="checkbox" name="permissions[<?php echo e($role->id); ?>][<?php echo e($permission->id); ?>][add]" <?php echo e($pivot?->can_add ? 'checked' : ''); ?>></label>
                                        <label>E <input type="checkbox" name="permissions[<?php echo e($role->id); ?>][<?php echo e($permission->id); ?>][edit]" <?php echo e($pivot?->can_edit ? 'checked' : ''); ?>></label>
                                        <label>D <input type="checkbox" name="permissions[<?php echo e($role->id); ?>][<?php echo e($permission->id); ?>][delete]" <?php echo e($pivot?->can_delete ? 'checked' : ''); ?>></label>
                                    </div>
                                </td>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <button class="btn btn-success mt-3">Save Permissions</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/settings/role_permissions.blade.php ENDPATH**/ ?>