
<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>📆 Scheduled Messages</h4>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Title</th>
                <th>Message</th>
                <th>Scheduled At</th>
                <th>Type</th>
                <th>Target</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $scheduled; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->template->title ?? 'N/A'); ?></td>
                    <td><?php echo e(Str::limit(strip_tags($item->template->content), 60)); ?></td>
                    <td><?php echo e($item->scheduled_at->format('M d, Y H:i')); ?></td>
                    <td><?php echo e(strtoupper($item->type)); ?></td>
                    <td><?php echo e(ucfirst($item->target_type)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\communication\logs_scheduled.blade.php ENDPATH**/ ?>