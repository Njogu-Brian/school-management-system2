<div class="tab-pane fade" id="modules" role="tabpanel">
    <form method="POST" action="<?php echo e(route('settings.update.modules')); ?>">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label>Enabled Modules</label>
            <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="modules[]" value="<?php echo e($module); ?>"
                        <?php echo e(in_array($module, $enabledModules) ? 'checked' : ''); ?>>
                    <label class="form-check-label">
                        <?php echo e(ucfirst(str_replace('_', ' ', $module))); ?>

                    </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <button class="btn btn-primary">Save Module Preferences</button>
    </form>
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\settings\partials\modules.blade.php ENDPATH**/ ?>