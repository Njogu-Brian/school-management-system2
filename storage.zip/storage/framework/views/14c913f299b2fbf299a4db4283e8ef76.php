<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Edit Student Assignment</h1>

    <form action="<?php echo e(route('student_assignments.update', $assignment->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <!-- Student Selection -->
        <div class="mb-3">
            <label for="student_id">Select Student</label>
            <select name="student_id" class="form-control">
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($student->id); ?>" <?php echo e($assignment->student_id == $student->id ? 'selected' : ''); ?>>
                        <?php echo e($student->first_name); ?> <?php echo e($student->last_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Route Selection -->
        <div class="mb-3">
            <label for="route_id">Select Route</label>
            <select name="route_id" class="form-control" id="route-select">
                <?php $__currentLoopData = $routes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($route->id); ?>" <?php echo e($assignment->route_id == $route->id ? 'selected' : ''); ?>>
                        <?php echo e($route->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Trip Selection -->
        <div class="mb-3">
            <label for="trip_id">Select Trip</label>
            <select name="trip_id" class="form-control" id="trip-select">
                <?php $__currentLoopData = $trips; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $trip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($trip->id); ?>" data-route="<?php echo e($trip->route_id); ?>" <?php echo e($assignment->trip_id == $trip->id ? 'selected' : ''); ?>>
                        <?php echo e($trip->trip_name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <!-- Drop-Off Point Selection -->
        <div class="mb-3">
            <label for="drop_off_point_id">Select Drop-Off Point</label>
            <select name="drop_off_point_id" class="form-control" id="drop-off-point-select">
                <?php $__currentLoopData = $dropOffPoints; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $point): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($point->id); ?>" data-route="<?php echo e($point->route_id); ?>" <?php echo e($assignment->drop_off_point_id == $point->id ? 'selected' : ''); ?>>
                        <?php echo e($point->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>

        <button type="submit" class="btn btn-primary">Update Assignment</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\student_assignments\edit.blade.php ENDPATH**/ ?>