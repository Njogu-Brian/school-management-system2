<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Mark Attendance</h1>

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="alert alert-success">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Class Selection Form -->
    <form method="GET" action="<?php echo e(route('attendance.mark.form')); ?>">
        <label for="class">Select Class:</label>
        <select name="class" id="class" class="form-control" onchange="this.form.submit()">
            <option value="">-- Select Class --</option>
            <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($id); ?>" <?php echo e(isset($selectedClass) && $selectedClass == $id ? 'selected' : ''); ?>>
                    <?php echo e($name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </form>

    <hr>

    <!-- Students List for Selected Class -->
    <?php if($students->isNotEmpty()): ?>
    <form method="POST" action="<?php echo e(route('attendance.mark')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="class" value="<?php echo e($selectedClass); ?>">

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Attendance</th>
                    <th>Reason (if absent)</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $totalPresent = 0;
                    $totalAbsent = 0;
                    $unmarkedAttendance = false;
                ?>
                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                        $attendance = $attendanceRecords->get($student->id);
                        if ($attendance) {
                            if ($attendance->is_present) {
                                $totalPresent++;
                            } else {
                                $totalAbsent++;
                            }
                        } else {
                            $unmarkedAttendance = true;
                        }
                    ?>
                    <tr>
                        <td>
                            <?php echo e($student->full_name ?? "{$student->first_name} {$student->middle_name} {$student->last_name}"); ?>

                        </td>
                        <td>
                            <select name="status_<?php echo e($student->id); ?>" class="form-control attendance-select" required>
                                <option value="">-- Select --</option>
                                <option value="1" <?php echo e(isset($attendance) && $attendance->is_present ? 'selected' : ''); ?>>Present</option>
                                <option value="0" <?php echo e(isset($attendance) && !$attendance->is_present ? 'selected' : ''); ?>>Absent</option>
                            </select>
                        </td>
                        <td>
                            <input type="text" name="reason_<?php echo e($student->id); ?>" 
                                   class="form-control reason-input"
                                   value="<?php echo e(isset($attendance) ? $attendance->reason : ''); ?>"
                                   <?php echo e((isset($attendance) && $attendance->is_present) ? 'disabled' : ''); ?>>
                        </td>
                        <td>
                            <?php if($attendance): ?>
                                <!-- Show Edit Button -->
                                <a href="<?php echo e(route('attendance.edit', $attendance->id)); ?>" class="btn btn-warning">Edit</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

        <!-- Summary Section -->
        <div class="mt-4">
            <h4>Attendance Summary</h4>
            <p><strong>Total Present:</strong> <?php echo e($totalPresent); ?></p>
            <p><strong>Total Absent:</strong> <?php echo e($totalAbsent); ?></p>
        </div>

        <!-- Submit Button (Only show if attendance isn't marked for all students) -->
        <?php if($unmarkedAttendance): ?>
            <button type="submit" class="btn btn-primary">Submit Attendance</button>
        <?php endif; ?>
    </form>
    <?php else: ?>
        <p>No students found for this class.</p>
    <?php endif; ?>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        document.querySelectorAll('.attendance-select').forEach(select => {
            select.addEventListener('change', function () {
                let studentId = this.name.split('_')[1];
                let reasonField = document.querySelector(`input[name="reason_${studentId}"]`);
                
                if (this.value == "0") {
                    reasonField.disabled = false;
                    reasonField.required = true; // Ensure reason is required when absent
                } else {
                    reasonField.disabled = true;
                    reasonField.required = false;
                    reasonField.value = ''; // Clear reason if marked Present
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\attendance\mark.blade.php ENDPATH**/ ?>