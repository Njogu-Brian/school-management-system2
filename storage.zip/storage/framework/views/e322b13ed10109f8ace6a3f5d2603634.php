

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Transport Details</h1>
    <p><strong>Vehicle Number:</strong> <?php echo e($vehicle->vehicle_number); ?></p>
    <p><strong>Make:</strong> <?php echo e($vehicle->make); ?></p>
    <p><strong>Model:</strong> <?php echo e($vehicle->model); ?></p>
    <p><strong>Type:</strong> <?php echo e($vehicle->type); ?></p>
    <p><strong>Capacity:</strong> <?php echo e($vehicle->capacity); ?></p>

    <a href="<?php echo e(route('vehicles.index')); ?>" class="btn btn-secondary">Back to Transport List</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\transport\show.blade.php ENDPATH**/ ?>