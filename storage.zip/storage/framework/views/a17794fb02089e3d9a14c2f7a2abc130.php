<div class="tab-pane fade" id="system" role="tabpanel">
    <form method="POST" action="<?php echo e(route('settings.update.system')); ?>">
        <?php echo csrf_field(); ?>

        <div class="mb-3">
            <label>System Version</label>
            <input type="text" class="form-control" name="system_version"
                value="<?php echo e($settings['system_version']->value ?? '1.0.0'); ?>" readonly>
        </div>

        <div class="mb-3">
            <label>Enable Backup</label>
            <select class="form-select" name="enable_backup">
                <?php
                    $enableBackup = $settings['enable_backup']->value ?? '0';
                ?>
                <option value="1" <?php echo e($enableBackup == '1' ? 'selected' : ''); ?>>Yes</option>
                <option value="0" <?php echo e($enableBackup == '0' ? 'selected' : ''); ?>>No</option>
            </select>
        </div>

        <button class="btn btn-primary">Save System Options</button>
    </form>
</div>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/settings/partials/system.blade.php ENDPATH**/ ?>