<?php $__env->startSection('content'); ?>
<h1>SMS Logs</h1>

<table>
    <thead>
        <tr>
            <th>Phone Number</th>
            <th>Message</th>
            <th>Created At</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $smsLogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($log->phone_number); ?></td>
                <td><?php echo e($log->message); ?></td>
                <td><?php echo e($log->created_at); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<form action="<?php echo e(route('admin.sms.logs.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="phone_number">Phone Number</label>
        <input type="text" name="phone_number" id="phone_number" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="message">Message</label>
        <textarea name="message" id="message" class="form-control" required></textarea>
    </div>
    <button type="submit" class="btn btn-primary">Send SMS</button>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\sms_logs\index.blade.php ENDPATH**/ ?>