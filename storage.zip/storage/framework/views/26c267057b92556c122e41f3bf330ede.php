<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Admin Dashboard</h1>
    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <?php if(Auth::user() && Auth::user()->hasRole('admin')): ?>
        <?php echo $__env->make('dashboard.partials.filters', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <div class="row">
            <div class="col-md-6">
                <h3>Students Overview</h3>
                <?php echo $__env->make('dashboard.partials.students', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>

            <div class="col-md-6">
                <h3>Attendance Summary</h3>
                <?php echo $__env->make('dashboard.partials.summary', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    <?php else: ?>
        <p class="text-danger">Unauthorized Access</p>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>