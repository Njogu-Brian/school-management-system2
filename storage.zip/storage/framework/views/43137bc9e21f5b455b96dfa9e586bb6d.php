

<?php $__env->startSection('content'); ?>
<h1>Add Route</h1>

<form action="<?php echo e(route('routes.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
        <label for="name">Route Name</label>
        <input type="text" name="name" class="form-control" required>
    </div>
    <div class="mb-3">
        <label for="area">Area</label>
        <input type="text" name="area" class="form-control">
    </div>
        <div class="mb-3">
        <label for="vehicle_ids">Assign Vehicles</label>
        <select name="vehicle_ids[]" class="form-control" multiple>
            <?php $__currentLoopData = $vehicles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehicle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($vehicle->id); ?>"
                    <?php if(isset($route) && $route->vehicles->contains($vehicle->id)): ?> selected <?php endif; ?>>
                    <?php echo e($vehicle->vehicle_number); ?> (Driver: <?php echo e($vehicle->driver_name ?? 'Unassigned'); ?>)
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <small class="text-muted">Hold Ctrl (or Cmd on Mac) to select multiple vehicles.</small>
    </div>

    <button class="btn btn-primary">Save</button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\routes\create.blade.php ENDPATH**/ ?>