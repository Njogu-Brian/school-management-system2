<?php $__env->startSection('content'); ?>
<div class="container">
    <h1 class="mb-4">Student Management</h1>

    
    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    
    <form method="GET" action="<?php echo e(route('students.index')); ?>" class="mb-4">
        <div class="row g-3">
            <div class="col-md-3">
                <label for="name">Name</label>
                <input type="text" name="name" class="form-control" id="name" value="<?php echo e(request('name')); ?>">
            </div>
            <div class="col-md-3">
                <label for="admission_number">Admission Number</label>
                <input type="text" name="admission_number" class="form-control" id="admission_number" value="<?php echo e(request('admission_number')); ?>">
            </div>
            <div class="col-md-3">
                <label for="classroom_id">Class</label>
                <select name="classroom_id" class="form-control" id="classroom_id">
                    <option value="">All Classes</option>
                    <?php $__currentLoopData = $classes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($class->id); ?>" <?php echo e(request('classroom_id') == $class->id ? 'selected' : ''); ?>>
                            <?php echo e($class->name); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="col-md-3">
                <label>&nbsp;</label>
                <div>
                    <button type="submit" class="btn btn-primary">Filter</button>
                    <a href="<?php echo e(route('students.index')); ?>" class="btn btn-secondary">Reset</a>
                </div>
            </div>
        </div>
    </form>

    
    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-success mb-3">Add New Student</a>

    
    <div class="table-responsive">
        <table class="table table-bordered table-hover">
            <thead class="table-dark">
                <tr>
                    <th>Admission Number</th>
                    <th>First Name</th>
                    <th>Middle Name</th>
                    <th>Last Name</th>
                    <th>Class</th>
                    <th>Stream</th>
                    <th>Category</th>
                    <th>Parent</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($student->admission_number); ?></td>
                        <td><?php echo e($student->first_name); ?></td>
                        <td><?php echo e($student->middle_name ?? 'N/A'); ?></td>
                        <td><?php echo e($student->last_name); ?></td>
                        <td><?php echo e($student->classroom->name ?? 'N/A'); ?></td>
                        <td><?php echo e($student->stream->name ?? 'N/A'); ?></td>
                        <td><?php echo e($student->category->name ?? 'N/A'); ?></td>
                        <td><?php echo e(optional($student->parent)->father_name ?? optional($student->parent)->mother_name ?? 'N/A'); ?></td>
                        <td>
                            <?php if($student->archive): ?>
                                <form action="<?php echo e(route('students.restore', $student->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-success btn-sm">Restore</button>
                                </form>
                            <?php else: ?>
                                <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-primary btn-sm">Edit</a>
                                <form action="<?php echo e(route('students.archive', $student->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-warning btn-sm">Archive</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="9" class="text-center">No students found.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\students\index.blade.php ENDPATH**/ ?>