

<?php $__env->startSection('content'); ?>
<div class="container">
    <h1>Transport Management</h1>
    <a href="<?php echo e(route('vehicles.create')); ?>" class="btn btn-primary">Add New Vehicle</a>
    <a href="<?php echo e(route('routes.create')); ?>" class="btn btn-success">Add New Route</a>

    <h2>Vehicles</h2>
    <!-- Display vehicle data here -->

    <h2>Routes</h2>
    <!-- Display routes data here -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\transport\index.blade.php ENDPATH**/ ?>