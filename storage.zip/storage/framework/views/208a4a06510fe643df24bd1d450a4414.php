

<?php $__env->startSection('content'); ?>
<div class="container">
    <h4>Create Email Template</h4>
    <form action="<?php echo e(route('email-templates.store')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label class="form-label">Template Code *</label>
            <input type="text" name="code" class="form-control" value="<?php echo e(old('code', $smsTemplate->code ?? $emailTemplate->code ?? '')); ?>" required>
            <small class="text-muted">Use a unique identifier like: welcome_staff, absent_notification</small>
        </div>
        <div class="mb-3">
            <label class="form-label">Title *</label>
            <input type="text" name="title" class="form-control" required>
        </div>

        <div class="mb-3">
            <label class="form-label">Attachment</label>
            <input type="file" name="attachment" class="form-control">
        </div>

        <div class="mb-3">
            <label class="form-label">Message *</label>
            <textarea name="message" class="form-control rich-text" rows="10" required></textarea>
        </div>

        <button type="submit" class="btn btn-primary">Save</button>
    </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views\communication\email_templates\create.blade.php ENDPATH**/ ?>