<?php echo csrf_field(); ?>

<div class="mb-3">
    <label>Title</label>
    <input type="text" name="title" class="form-control" value="<?php echo e(old('title', $announcement->title ?? '')); ?>" required>
</div>

<div class="mb-3">
    <label>Content</label>
    <textarea name="content" class="form-control" rows="4" required><?php echo e(old('content', $announcement->content ?? '')); ?></textarea>
</div>

<div class="mb-3">
    <label>Status</label>
    <select name="active" class="form-select">
        <option value="1" <?php echo e((old('active', $announcement->active ?? 1) == 1) ? 'selected' : ''); ?>>Active</option>
        <option value="0" <?php echo e((old('active', $announcement->active ?? 1) == 0) ? 'selected' : ''); ?>>Inactive</option>
    </select>
</div>

<div class="mb-3">
    <label>Expires At (optional)</label>
    <input type="date" name="expires_at" class="form-control" value="<?php echo e(old('expires_at', isset($announcement->expires_at) ? $announcement->expires_at->format('Y-m-d') : '')); ?>">
</div>

<button type="submit" class="btn btn-primary">
    <?php echo e(isset($announcement) ? 'Update' : 'Create'); ?> Announcement
</button>
<?php /**PATH C:\Users\brian\Videos\School\school-management-system2\resources\views/communication/announcements/partials/_form.blade.php ENDPATH**/ ?>