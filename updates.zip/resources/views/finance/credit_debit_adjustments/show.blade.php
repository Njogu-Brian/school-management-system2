<!-- show.blade.php for credit_debit_adjustments -->
