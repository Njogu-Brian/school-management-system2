@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Subject Group Management</h1>
    <p>Create and manage subject groups here.</p>
    <a href="#" class="btn btn-primary">Create Subject Group</a>
</div>
@endsection
