@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Class Management</h1>
    <p>Create and manage classes for the school.</p>
    <a href="#" class="btn btn-primary">Create New Class</a>
</div>
@endsection
