@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Sections Management</h1>
    <p>Manage class sections and streams for your school.</p>
    <a href="#" class="btn btn-primary">Add New Section</a>
</div>
@endsection
