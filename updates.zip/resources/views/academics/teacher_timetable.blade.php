@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Teacher Timetable Management</h1>

    <p>Manage teacher timetables here. Assign classes and subjects to teachers.</p>

    <a href="#" class="btn btn-primary">Add Teacher Timetable</a>
</div>
@endsection
