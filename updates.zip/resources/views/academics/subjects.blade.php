@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Subjects Management</h1>
    <p>Add, edit, or remove subjects for different classes.</p>
    <a href="#" class="btn btn-primary">Add New Subject</a>
</div>
@endsection
