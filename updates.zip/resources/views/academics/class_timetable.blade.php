@extends('layouts.app')

@section('content')
<div class="container">
    <h1>Class Timetable Management</h1>

    <p>Here you can create, edit, and view class timetables.</p>

    <a href="#" class="btn btn-primary">Add New Timetable</a>
</div>
@endsection
