<p>Hello,</p>
<p>Your account has been created.</p>
<p><strong>Email:</strong> {{ $email }}</p>
<p><strong>Password:</strong> {{ $password }}</p>
<p>Please log in and change your password immediately.</p>
