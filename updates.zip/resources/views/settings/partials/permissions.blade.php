<div class="tab-pane fade" id="permissions" role="tabpanel">
    <h5 class="mt-3">User Roles & Permissions</h5>
    <div class="alert alert-warning">🔒 Permission management will be handled in a dedicated module. This section will link to Roles & Access Control.</div>
    <a href="{{ route('roles.index') }}" class="btn btn-outline-primary">Manage Roles</a>
</div>
